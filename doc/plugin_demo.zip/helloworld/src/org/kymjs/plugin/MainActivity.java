package org.kymjs.plugin;

import org.kymjs.kjframe.plugin.CJActivity;

public class MainActivity extends CJActivity {

    @Override
    public void setRootView() {
        that.setContentView(R.layout.activity_main);
    }
}