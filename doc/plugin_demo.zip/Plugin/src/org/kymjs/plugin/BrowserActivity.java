package org.kymjs.plugin;

import org.kymjs.kjframe.plugin.CJActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

/**
 * 简易浏览器
 * 
 * @author caolicheng
 */
public class BrowserActivity extends CJActivity {

    public static final String BROWSER_URL = "browser_rul";

    // 顶部
    private RelativeLayout mRlTopbar;
    private Button mBtnBack;
    // 主体
    private WebView mWebView;
    private ProgressBar mProgressBar;
    // 底部
    private LinearLayout mLlBottombar;
    private Button mBottomBack;
    private Button mBottomForward;
    private Button mBottomSave;
    private Button mBottomShare;

    private Activity aty;
    private int TAG = 1; // 双击事件需要
    private String mCurrentUrl = "http://www.baidu.com";

    private GestureDetector mGestureDetector;
    private Animation animTopIn, animBottomIn, animTopOut, animBottomOut;

    @Override
    public void setRootView() {
        that.setContentView(R.layout.aty_browser);
        aty = that;
    }

    @Override
    public void initWidget() {
        super.initWidget();
        bindView();
        initWebView();
        initBarAnim();
        mProgressBar.setProgress(0); // 初始Progress为0
        mProgressBar.setMax(100); // 指定Progress为最多100

        mGestureDetector = new GestureDetector(aty, new MyGestureListener());
        mWebView.loadUrl(mCurrentUrl);
        mWebView.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return mGestureDetector.onTouchEvent(event);
            }
        });
    }

    private void bindView() {
        mRlTopbar = (RelativeLayout) that
                .findViewById(R.id.browser_bottombar_topbar);
        mBtnBack = (Button) that.findViewById(R.id.browser_topbar_back);
        mWebView = (WebView) that.findViewById(R.id.webView);
        mProgressBar = (ProgressBar) that.findViewById(R.id.progressBar);
        mLlBottombar = (LinearLayout) that
                .findViewById(R.id.browser_bottombar_bottombar);
        mBottomBack = (Button) that.findViewById(R.id.browser_bottombar_back);
        mBottomForward = (Button) that
                .findViewById(R.id.browser_bottombar_forward);
        mBottomSave = (Button) that.findViewById(R.id.browser_bottombar_save);
        mBottomShare = (Button) that.findViewById(R.id.browser_bottombar_share);

        mBottomShare.setOnClickListener(this);
        mBottomSave.setOnClickListener(this);
        mBottomForward.setOnClickListener(this);
        mBottomBack.setOnClickListener(this);
        mLlBottombar.setOnClickListener(this);
        mBtnBack.setOnClickListener(this);
    }

    /**
     * 初始化上下栏的动画并设置结束监听事件
     */
    private void initBarAnim() {
        animTopIn = AnimationUtils.loadAnimation(aty, R.anim.anim_top_in);
        animBottomIn = AnimationUtils.loadAnimation(aty, R.anim.anim_bottom_in);
        animTopOut = AnimationUtils.loadAnimation(aty, R.anim.anim_top_out);
        animBottomOut = AnimationUtils.loadAnimation(aty,
                R.anim.anim_bottom_out);

        animTopIn.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                mRlTopbar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {}
        });

        animTopOut.setAnimationListener(new AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationRepeat(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                mRlTopbar.setVisibility(View.GONE);
            }
        });

        animBottomIn.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationRepeat(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                mLlBottombar.setVisibility(View.VISIBLE);
            }
        });

        animBottomOut.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationRepeat(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                mLlBottombar.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void widgetClick(View v) {
        super.widgetClick(v);
        switch (v.getId()) {
        case R.id.browser_topbar_back:
            that.finish();
            break;
        case R.id.browser_bottombar_back:
            mWebView.goBack();
            break;
        case R.id.browser_bottombar_forward:
            mWebView.goForward();
            break;
        case R.id.browser_bottombar_save:
            break;
        case R.id.browser_bottombar_share:
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/*");
            intent.putExtra(Intent.EXTRA_SUBJECT, "Share");
            intent.putExtra(Intent.EXTRA_TEXT, mCurrentUrl);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            that.startActivity(Intent.createChooser(intent, getTitle()));
            break;
        default:
            break;
        }
    }

    /**
     * 载入链接之前会被调用
     * 
     * @param view
     *            WebView
     * @param url
     *            链接地址
     */
    protected void onUrlLoading(WebView view, String url) {}

    /**
     * 链接载入成功后会被调用
     * 
     * @param view
     *            WebView
     * @param url
     *            链接地址
     */
    protected void onUrlFinished(WebView view, String url) {}

    /**
     * 获取当前WebView显示页面的标题
     * 
     * @param view
     *            WebView
     * @param title
     *            web页面标题
     */
    protected void getWebTitle(WebView view, String title) {}

    /**
     * 获取当前WebView显示页面的图标
     * 
     * @param view
     *            WebView
     * @param icon
     *            web页面图标
     */
    protected void getWebIcon(WebView view, Bitmap icon) {}

    /**
     * 初始化浏览器设置信息
     */
    private void initWebView() {
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setJavaScriptEnabled(true); // 启用支持javascript
        webSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);// 优先使用缓存
        webSettings.setAllowFileAccess(true);// 可以访问文件
        webSettings.setBuiltInZoomControls(true);// 支持缩放
        mWebView.setWebViewClient(new MyWebViewClient());
        mWebView.setWebChromeClient(new MyWebChromeClient());
    }

    private class MyWebChromeClient extends WebChromeClient {
        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
            getWebTitle(view, title);
        }

        @Override
        public void onReceivedIcon(WebView view, Bitmap icon) {
            super.onReceivedIcon(view, icon);
            getWebIcon(view, icon);
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) { // 进度
            super.onProgressChanged(view, newProgress);
            if (newProgress == 100) {
                mProgressBar.setVisibility(View.GONE);
            } else {
                mProgressBar.setVisibility(View.VISIBLE);
                mProgressBar.setProgress(newProgress);
            }
        }
    }

    private class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            onUrlLoading(view, url);
            mCurrentUrl = url;
            return super.shouldOverrideUrlLoading(view, url);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            onUrlFinished(view, url);
        }
    }

    private class MyGestureListener extends SimpleOnGestureListener {

        @Override
        public boolean onDoubleTap(MotionEvent e) {// webview的双击事件
            if (TAG % 2 == 0) {
                TAG++;
                mRlTopbar.startAnimation(animTopIn);
                mLlBottombar.startAnimation(animBottomIn);
            } else {
                TAG++;
                mRlTopbar.startAnimation(animTopOut);
                mLlBottombar.startAnimation(animBottomOut);
            }
            return super.onDoubleTap(e);
        }

    }
}